from asos_automation_proj.pages.login_wizard import LoginWizard
from asos_automation_proj.pages.home_wizard import HomepageWizard
from asos_automation_proj.pages.product_wizard import ProductPage


class BaseTest:

    login_page: LoginWizard
    home_page: HomepageWizard
    product_page: ProductPage

