import time

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.maximize_window()
#driver.get("https://whatismyipaddress.com/")

#IP = driver.find_element(By.CSS_SELECTOR, "#ipv6").text
#print(IP)
IP = "2a06:c701:95a9:4600:3cf3:271e:8a38:6f2f"

driver.get("https://apps.db.ripe.net/db-web-ui/query")
time.sleep(3)
driver.find_element(By.CSS_SELECTOR, "#queryStringInput").send_keys(IP)
driver.find_element(By.CSS_SELECTOR, ".mat-icon.notranslate.fal.fa-search.material-icons.mat-ligature-font.mat-icon-no-color").click()

info_box = driver.find_elements(By.CSS_SELECTOR, ".clearfix.ng-star-inserted a")
print(info_box)


input("wwe")